import { Icon } from '@iconify/react/dist/iconify.js'
import React from 'react'
import background from '@/assets/images/background/1.png'

const Contact = () => {
    return (
        <section id="contact" className="py-22.5 bg-body-bg">
            <div className="container">
                <div className="mb-12 lg:w-3/5 mx-auto">
                    <div className="mb-6 flex items-center justify-center">
                        <div className="size-7.5 bg-primary rounded-md flex justify-center items-center">
                            <Icon icon='tabler:address-book' className="iconify text-white size-4.5 " />
                        </div>
                        <Icon icon='tabler:line-dashed' className="iconify text-primary size-5" />
                        <div className="py-2 px-4 bg-body-bg text-primary border rounded-md text-sm border-bg">
                            Contact
                        </div>
                    </div>
                    <h3 className="mb-2 lg:text-2.8xl md:text-2.5xl text-2.3xl text-center">
                        Contact Us</h3>
                    <p className="mb-4 text-secondary text-center">We're here to help! Whether you have questions, need support,
                        or want to explore how we can collaborate</p>
                </div>
                <div className="grid lg:grid-cols-3 gap-9">
                    <div className="lg:col-span-1">
                        <div className="flex gap-6 flex-col">
                            <div className="rounded-md p-4 bg-primary bg-cover" style={{ backgroundImage: `url(${background.src})` }}>
                                <div className="flex gap-3 items-center">
                                    <div className="bg-white rounded-sm size-10 flex justify-center items-center">
                                        <Icon icon='tabler:phone-call' className="iconify text-primary size-6" />
                                    </div>
                                    <p className="text-white">Call Us Directly At</p>
                                </div>
                                <h5 className="text-xl text-white mb-12 mt-6 ">+ 713-707-2524</h5>
                                <button className="py-1.75 px-4.5 w-full bg-white text-primary rounded-full border border-primary border-b-3 border-b-light ">
                                    Contact Us
                                </button>
                            </div>
                            <div className="rounded-md p-4 bg-white ">
                                <div className="flex gap-3 items-center">
                                    <div className="rounded-sm size-10 flex justify-center items-center border border-primary bg-body-bg">
                                        <Icon icon='tabler:mail' className="iconify text-primary size-6" />
                                    </div>
                                    <p className="text-secondary">Chat With Our Team</p>
                                </div>
                                <h5 className="text-xl mb-12 mt-6 ">marshal@rhyta.com</h5>
                                <button className="py-1.75 px-4.5 w-full bg-primary text-white rounded-full border border-primary border-b-3 border-b-orange-100 hover:bg-orange-200 hover:border-b-orange-300 transition-all duration-300">
                                    Contact Us
                                </button>
                            </div>
                        </div>
                    </div>
                    <div className="lg:col-span-2">
                        <h6 className="mb-6">Send Details</h6>
                        <div className="grid grid-cols-2 gap-6">
                            <div className="col-span-1">
                                <input name="name" type="text" className="py-1.5 px-4.5 h-11.25 w-full mb-4 rounded-md border border-bg" placeholder="Name" required />
                            </div>
                            <div className="col-span-1">
                                <input name="email" type="text" className="py-1.5 px-4.5 h-11.25 w-full mb-4 rounded-md border border-bg" placeholder="Email" required />
                            </div>
                        </div>
                        <input name="name" type="text" className="py-1.5 px-4.5 h-11.25 w-full mb-4 rounded-md border border-bg" placeholder="Subject" required />
                        <textarea name="comments" id="comments" rows={8} className="py-1.5 px-4.5 w-full mb-4 rounded-md border border-bg" required placeholder="Message" defaultValue={""} />
                        <button className="py-3 px-6.25 bg-primary text-white rounded-full border border-primary border-b-3 border-b-orange-100">Send
                            Message
                        </button>
                    </div>
                </div>
            </div>
        </section>


    )
}

export default Contact