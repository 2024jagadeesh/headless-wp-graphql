import { Icon } from '@iconify/react/dist/iconify.js'
import React from 'react'
import background from '@/assets/images/background/1.png'

type ServiceType = {
    title: string,
    description: string,
    icon: string,
    popular?: boolean
    background: string,
}

const ServiceData: ServiceType[] = [
    {
        title: "Custom Software Development",
        description: "We understand that every business has unique needs. Our team can create custom software solutions tailored specifically",
        icon: "tabler:device-desktop-analytics",
        background: "white",
    },
    {
        title: "Integration Services",
        description: "Our software seamlessly integrates with a variety of platforms and tools. We provide integration services to ensure",
        icon: "tabler:webhook",
        background: "primary-with-image",
        popular: true
    },
    {
        title: "Training and Onboarding",
        description: "We offer thorough training programs and onboarding sessions to help your team get up to speed with our software quickly",
        icon: "tabler:heart-handshake",
        background: "white",
    },
    {
        title: "Consulting Services",
        description: "Our experts provide strategic consulting to help you leverage our software for maximum benefit. We offer insights",
        icon: "tabler:message-user",
        background: "white",
    },
    {
        title: "Updates and Maintenance",
        description: "We continually update our software to incorporate the latest advancements and features. Our maintenance services",
        icon: "tabler:refresh-dot",
        background: "white",
    },
    {
        title: "Technical Support",
        description: "Our dedicated support team is available 24/7 to assist you with any technical issues you may encounter.",
        icon: "tabler:headset",
        background: "white",
    }
]


const Services = () => {
    return (
        <section id="services" className="py-22.5">
            <div className="container">
                <div className="mb-12 lg:w-3/5 mx-auto">
                    <div className="mb-6 flex items-center justify-center">
                        <div className="size-7.5 bg-primary rounded-md flex justify-center items-center">
                            <Icon icon='tabler:devices-cog' className="iconify text-white size-4.5 " />
                        </div>
                        <Icon icon='tabler:line-dashed' className="iconify text-primary size-5" />
                        <div className="py-2 px-4 bg-body-bg text-primary border rounded-md text-sm border-bg">
                            Our Services
                        </div>
                    </div>
                    <h3 className="mb-2 lg:text-2.8xl md:text-2.5xl text-2.3xl text-center">How To Better Into Business</h3>
                    <p className="mb-4 text-secondary text-center">Improving one's business acumen and navigating the
                        complexities of entrepreneurship require
                    </p>
                </div>
                <div className="grid lg:grid-cols-3 gap-4">
                    {
                        ServiceData.map((service, index) => (
                            <div className="col-span-1" key={index}>
                                <div className={`rounded-md p-4 ${service.popular ? 'bg-primary bg-cover' : 'bg-white'}`} style={service.background === 'primary-with-image' ? { backgroundImage: `url(${background.src})` } : {}}>
                                    <div className="text-center">
                                        <Icon icon={service.icon} className={`iconify ${service.background === 'primary-with-image' ? 'text-white' : 'text-primary'} mx-auto size-10 mb-4`} />
                                        <h6 className={`${service.popular ? 'text-white' : 'text-dark'}  mb-2`}>{service.title}</h6>
                                        <p className={` ${service.popular ? 'text-light-100' : 'text-secondary'} mt-2 mb-4`}>{service.description}</p>
                                        <a href="#" className={`${service.background === 'primary-with-image' ? 'text-white' : 'text-primary'}`}>View More</a>
                                    </div>
                                </div>
                            </div>
                        ))
                    }

                </div>
            </div>
        </section>

    )
}

export default Services