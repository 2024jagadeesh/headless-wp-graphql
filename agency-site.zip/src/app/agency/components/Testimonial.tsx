"use client";
import Image, { StaticImageData } from "next/image";
import React, { useRef } from "react";
import avatar1 from "@/assets/images/avatar/1.jpg";
import avatar3 from "@/assets/images/avatar/3.jpg";
import avatar4 from "@/assets/images/avatar/4.jpg";
import avatar5 from "@/assets/images/avatar/5.jpg";
import paypal from "@/assets/images/logo/paypal.png";
import shopify from "@/assets/images/logo/shopify.png";
import amazon from "@/assets/images/logo/amazon.png";
import { Icon } from "@iconify/react/dist/iconify.js";
import type { Swiper as SwiperType } from "swiper";

import background from "@/assets/images/background/1.png";
import { Swiper, SwiperSlide } from "swiper/react";
import { Navigation } from "swiper/modules";

type TestimonialType = {
  brand: string;
  brandLogo: StaticImageData;
  quote: string;
  userName: string;
  userTitle: string;
  userAvatar: StaticImageData;
};

const TestimonialData: TestimonialType[] = [
  {
    brand: "PayPal",
    brandLogo: paypal,
    quote:
      "Production Online has helped me become a bette musician and producer tha I ever thought possible.",
    userName: "Danilo Tanic",
    userTitle: "Head of Design at Paypal",
    userAvatar: avatar1,
  },
  {
    brand: "Shopify",
    brandLogo: shopify,
    quote:
      "Each of team member is getting precious help in their professional development and can build a program that.",
    userName: "Danilo Tanic",
    userTitle: "Head of Design at Paypal",
    userAvatar: avatar1,
  },
  {
    brand: "Amazon",
    brandLogo: amazon,
    quote:
      "Growth was implemented within minutes and it is now an essential part of our amazing development process.",
    userName: "Danilo Tanic",
    userTitle: "Head of Design at Paypal",
    userAvatar: avatar1,
  },
  {
    brand: "Amazon",
    brandLogo: amazon,
    quote:
      "Growth was implemented within minutes and it is now an essential part of our amazing development process.",
    userName: "Danilo Tanic",
    userTitle: "Head of Design at Paypal",
    userAvatar: avatar1,
  },
];

const Testimonial = () => {
  const swiperRef = useRef<SwiperType | null>(null);
  return (
    <section id="reviews" className="py-22.5 bg-body-bg">
      <div className="container">
        <div className="grid lg:grid-cols-11 grid-cols-1 lg:gap-30 gap-6">
          <div className="lg:col-span-5 col-span-1">
            <div className="mb-6 flex items-center">
              <div className="size-7.5 bg-primary rounded-md flex justify-center items-center">
                <Icon
                  icon="tabler:message"
                  className="iconify text-white size-4.5 "
                />
              </div>
              <Icon
                icon="tabler:line-dashed"
                className="iconify text-primary size-5"
              />
              <div className="py-2 px-4 bg-body-bg text-primary border rounded-md text-sm border-bg">
                Testimonial
              </div>
            </div>
            <h3 className="mb-2 text-2.6xl">From Our Community.</h3>
            <p className="mb-4 text-secondary">
              Here's what other subscribers had to say about Production Online.
            </p>
            <div className="flex mb-4 gap-2.75">
              {[avatar1, avatar3, avatar4, avatar5].map((img, idx) => (
                <button
                  key={idx}
                  onClick={() => swiperRef.current?.slideToLoop(idx)}
                >
                  <Image
                    alt="avatar"
                    src={img}
                    className="size-11 rounded-full border-3 border-white"
                  />
                </button>
              ))}
            </div>
            <div className="flex gap-1 items-center">
              <Icon
                icon="tabler--star-filled"
                className="iconify tabler--star-filled text-yellow size-6"
              />
              <h4 className="text-dark text-2xl">4.5</h4>
              <p className="text-secondary text-sm">Best Review</p>
            </div>
          </div>
          <div className="lg:col-span-6 col-span-1">
            <div
              className="relative overflow-hidden bg-white border-primary border-16 text-center bg-cover rounded-md lg:w-136.5 md:w-full"
              style={{ backgroundImage: `url(${background.src})` }}
            >
              <div className="flex transition-transform duration-700 ease-in-out">
                <Swiper
                  modules={[Navigation]}
                  loop={true}
                  onSwiper={(swiper) => (swiperRef.current = swiper)}
                  navigation={{
                    nextEl: ".custom-next",
                    prevEl: ".custom-prev",
                  }}
                  className="testiSwiper w-full"
                >
                  {TestimonialData.map((testimonial, index) => (
                    <SwiperSlide
                      className="w-full p-4 flex-shrink-0"
                      key={index}
                    >
                      <div>
                        <Image
                          src={testimonial.brandLogo}
                          alt={testimonial.brand}
                        />
                        <p className="my-4 text-secondary text-lg text-start">
                          {testimonial.quote}
                        </p>
                        <div className="mt-6 flex gap-4 items-center">
                          <Image
                            src={testimonial.userAvatar}
                            alt={testimonial.userName}
                            className="rounded-full size-12.5"
                          />
                          <div>
                            <p className="text-primary text-start">
                              {testimonial.userName}
                            </p>
                            <p className="text-dark">{testimonial.userTitle}</p>
                          </div>
                        </div>
                      </div>
                    </SwiperSlide>
                  ))}
                </Swiper>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonial;
