import { Icon } from '@iconify/react/dist/iconify.js'
import Image from 'next/image'
import React from 'react'
import team6 from '@/assets/images/team/6.jpg'
import avatar7 from '@/assets/images/avatar/7.jpg'
import avatar1 from '@/assets/images/avatar/1.jpg'
import team9 from '@/assets/images/team/9.jpg'
import hero8 from '@/assets/images/hero/8.png'

const Hero = () => {
    return (
        <section id="home" className="relative before:content-[''] bg-body-bg before:absolute before:top-0 h-full before:left-[67%] before:bottom-0 before:right-0 before:bg-pink-100 py-45 bg-[length:85px_85px] bg-[linear-gradient(#ffefed_2px,transparent_2px),linear-gradient(to_right,#ffefed_2px,transparent_2px)] bg-repeat w-full">
            <div className="container">
                <div>
                    <div className="grid lg:grid-cols-12 gap-6">
                        <div className="lg:col-span-5">
                            <div className="py-1 px-2 border border-bg mb-6 inline-flex rounded-full items-center">
                                <a href="#" className="bg-primary py-0.75 px-2 text-white rounded-full text-xs me-2">
                                    New
                                </a>
                                <p className="text-primary me-2 font-medium"> Show Product</p>
                                <Icon icon='tabler:arrow-narrow-right' className="iconify tabler--arrow-narrow-right text-primary size-4" />
                            </div>
                            <h1 className="mb-2 lg:text-4.0xl md:text-3.3xl text-2.7xl">Crafting Digital Solutions for Your
                                Success</h1>
                            <p className="text-secondary mb-4">At the heart of our mission is your success. We specialize in
                                developing cutting-edge digital products tailored to meet your unique needs.</p>
                            <div className="flex gap-6 mt-6">
                                <div className="gap-3.75 flex">
                                    <div>
                                        <Icon icon='tabler:circle-check-filled' className="iconify tabler--circle-check-filled text-green size-5" />
                                    </div>
                                    <div>
                                        <p className="text-dark font-medium"> 7 Day Free Trial</p>
                                    </div>
                                </div>
                                <div className="gap-3.75 flex">
                                    <div>
                                        <Icon icon='tabler:circle-check-filled' className="iconify tabler--circle-check-filled text-green size-5" />
                                    </div>
                                    <div>
                                        <p className="text-dark font-medium"> Easy To Set Up</p>
                                    </div>
                                </div>
                            </div>
                            <div className="flex gap-4 mt-4 items-center">
                                <div className="my-6 flex pt-1 pb-2">
                                    <Image src={team6} alt='team6' className="rounded-full size-13 border-white border-3" />
                                    <Image src={avatar7} alt='avatar7' className="rounded-full size-13 border-white border-3 -ms-3" />
                                    <Image src={avatar1} alt='avatar1' className="rounded-full size-13 border-white border-3 -ms-3" />
                                    <Image src={team9} alt='team9' className="rounded-full size-13 border-white border-3 -ms-3" />
                                </div>
                                <div>
                                    <h6 className="mb-1">100K</h6>
                                    <h6 className="mb-2">Active User</h6>
                                </div>
                            </div>
                            <div className="mt-6 flex gap-6">
                                <button className="py-3 px-6.25  bg-primary text-white rounded-full border border-primary border-b-3 border-b-orange-100 hover:bg-orange-200 hover:border-b-orange-300 transition-all duration-300">
                                    Explore Now
                                </button>
                                <button className="py-3 px-6.25  text-primary rounded-full border border-primary hover:bg-primary hover:text-white transition-all duration-300">
                                    Watch Video
                                </button>
                            </div>
                        </div>
                        <div className="lg:col-span-7">
                            <Image src={hero8} alt="hero8" />
                        </div>
                    </div>
                </div>
            </div>
        </section>

    )
}

export default Hero