import React from 'react'
import background from '@/assets/images/background/1.png'

const Counter = () => {
  return (
    <section className="bg-primary bg-cover" style={{ backgroundImage: `url(${background.src})` }}>
      <div className="container">
        <div className="grid lg:grid-cols-4 py-12 gap-6">
          <div className="col-span-1">
            <div className="flex items-center gap-6">
              <h2 className="lg:text-3.2xl md:text-2.8xl text-2xl font-bold text-white">
                230
              </h2>
              <p className="text-white">Startups We Have Funded</p>
            </div>
          </div>
          <div className="col-span-1">
            <div className="flex items-center gap-6">
              <h2 className="lg:text-3.2xl md:text-2.8xl text-2xl font-bold text-white">
                7k
              </h2>
              <p className="text-white">Funded From Skywave Community</p>
            </div>
          </div>
          <div className="col-span-1">
            <div className="flex items-center gap-6">
              <h2 className="lg:text-3.2xl md:text-2.8xl text-2xl font-bold text-white">
                $68B
              </h2>
              <p className="text-white">Our Combined Valuation</p>
            </div>
          </div>
          <div className="col-span-1">
            <div className="flex items-center gap-6">
              <h2 className="lg:text-3.2xl md:text-2.8xl text-2xl font-bold text-white">
                10+
              </h2>
              <p className="text-white">Years Of Best Experience</p>
            </div>
          </div>
        </div>
      </div>
    </section>

  )
}

export default Counter