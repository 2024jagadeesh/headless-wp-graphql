import { Icon } from '@iconify/react/dist/iconify.js'
import React from 'react'

type FeatureType = {
    title: string
    description: string
    icon: string
}

const FeatureData: FeatureType[] = [
    {
        title: "App Integration",
        description: "Our product seamlessly integrates with various apps, allowing you to streamline your workflow and enhance productivity.",
        icon: "tabler:apps",
    },
    {
        title: "Workflow Builder",
        description: "The Workflow Builder feature empowers you to create, customize, and automate tasks with ease. Design efficient workflows.",
        icon: "tabler:jump-rope",
    },
    {
        title: "Specific Tools",
        description: "Our product comes equipped with a range of specific tools designed to enhance functionality and improve efficiency.",
        icon: "tabler:edit",
    },
    {
        title: "Lifetime Access",
        description: "Enjoy the peace of mind that comes with Lifetime Access to our product. Once you purchase, you'll receive ongoing updates, support.",
        icon: "tabler:alarm",
    }
]


const Features = () => {
    return (
        <section id="feature" className="py-22.5 bg-body-bg">
            <div className="container">
                <div className="flex justify-between">
                    <div className="grid lg:grid-cols-2 lg:gap-30 gap-6">
                        <div>
                            <div className="mb-6 flex items-center ">
                                <div className="size-7.5 bg-primary rounded-md flex justify-center items-center">
                                    <Icon icon='tabler:key' className="iconify tabler--key text-white size-4.5 " />
                                </div>
                                <Icon icon='tabler:line-dashed' className="iconify tabler--line-dashed text-primary size-5" />
                                <div className="py-2 px-4 bg-body-bg text-primary border rounded-md text-sm border-bg">
                                    Features
                                </div>
                            </div>
                            <h3 className="mb-2 lg:text-2.8xl md:text-2.5xl text-2.3xl">Amazing Features</h3>
                            <p className="mb-4 text-secondary">Their diverse skills and creative approaches ensure that we
                                consistently deliver outstanding results and push the boundaries of what's possible.</p>
                        </div>
                        <div className="flex items-center lg:justify-end">
                            <button className="py-3 px-6.25  bg-primary text-white rounded-full border border-primary border-b-3 border-b-orange-100 hover:bg-orange-200 hover:border-b-orange-300 transition-all duration-300">Get
                                View !2 Features
                            </button>
                        </div>
                    </div>
                </div>
                <div className="grid lg:grid-cols-2 gap-4 mt-12">
                    {
                        FeatureData.map((feature, index) => (
                            <div className="col-span-1" key={index}>
                                <div className="bg-white p-4 rounded-md">
                                    <div className="mb-4">
                                        <div className="flex gap-4 items-center">
                                            <div className="size-10 rounded-md bg-orange flex justify-center items-center">
                                                <Icon icon={feature.icon} className="iconify tabler--apps text-primary size-6" />
                                            </div>
                                            <p className="text-dark font-semibold text-lg">{feature.title}</p>
                                        </div>
                                    </div>
                                    <p className="text-secondary mb-4">{feature.description}</p>
                                    <a href="#" className="text-primary">View More</a>
                                </div>
                            </div>
                        ))
                    }
                </div>
            </div>
        </section>

    )
}

export default Features