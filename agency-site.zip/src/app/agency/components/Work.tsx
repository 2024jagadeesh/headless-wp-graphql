import React from 'react'
import hero7 from '@/assets/images/hero/7.png'
import about4 from '@/assets/images/about/4.png'
import about5 from '@/assets/images/about/5.png'
import Image, { StaticImageData } from 'next/image'
import { Icon } from '@iconify/react/dist/iconify.js'

type WorkType = {
    title: string
    description: string
    image: StaticImageData,
}

const WorkData: WorkType[] = [
    {
        title: "Our Best Skywave App",
        description: "We are a digital agency that specializes in web design, SEO, social media",
        image: hero7,
    },
    {
        title: "Agency Landing Page",
        description: "We are a digital agency that specializes in web design, SEO, social media",
        image: about4,
    },
    {
        title: "Business Landing Pag",
        description: "We are a digital agency that specializes in web design, SEO, social media",
        image: about5,
    }
]


const Work = () => {
    return (
        <section className="py-22.5 bg-body-bg">
            <div className="container">
                <div className="mb-12 lg:w-3/5 mx-auto">
                    <div className="mb-6 flex items-center justify-center">
                        <div className="size-7.5 bg-primary rounded-md flex justify-center items-center">
                            <Icon icon='tabler:presentation' className="iconify text-white size-4.5 " />
                        </div>
                        <Icon icon='tabler:line-dashed' className="iconify text-primary size-5" />
                        <div className="py-2 px-4 bg-body-bg text-primary border rounded-md text-sm border-bg">
                            Our Project
                        </div>
                    </div>
                    <h3 className="mb-2 lg:text-2.8xl md:text-2.5xl text-2.3xl text-center">Discover Our Selected Projects</h3>
                    <p className="mb-4 text-secondary text-center">Explore the innovative and impactful work we’ve done across
                        various industries. Each project showcases our commitment to quality
                    </p>
                </div>
                <div className="grid lg:grid-cols-3 gap-4">
                    {
                        WorkData.map((work, index) => (
                            <div className="col-span-1" key={index}>
                                <div className="p-4 border border-bg rounded-md bg-white">
                                    <Image src={work.image} alt={work.title} className="bg-body-bg" />
                                    <div className="mt-4">
                                        <h5 className="mb-2 text-xl">{work.title}</h5>
                                        <p className="mb-2 text-secondary">{work.description}</p>
                                        <a href="#" className="text-primary"> Show More</a>
                                    </div>
                                </div>
                            </div>
                        ))
                    }
                    
                </div>
            </div>
        </section>

    )
}

export default Work