import { Icon } from '@iconify/react/dist/iconify.js'
import React from 'react'
import background from '@/assets/images/background/1.png'

const Pricing = () => {
    return (
        <section id="pricing" className="py-22.5">
            <div className="container">
                <div className="mb-12 lg:w-3/5 mx-auto">
                    <div className="mb-6 flex items-center justify-center">
                        <div className="size-7.5 bg-primary rounded-md flex justify-center items-center">
                            <Icon icon='tabler:receipt-2' className="iconify text-white size-4.5 " />
                        </div>
                        <Icon icon='tabler:line-dashed' className="iconify text-primary size-5" />
                        <div className="py-2 px-4 bg-body-bg text-primary border rounded-md text-sm border-bg">
                            Pricing
                        </div>
                    </div>
                    <h3 className="mb-2 lg:text-2.8xl md:text-2.5xl text-2.3xl text-center">Choose The Plan That's Right For You
                    </h3>
                    <p className="mb-4 text-secondary text-center">Competitive rates and pricing plans to help you find a plan
                        that fits the needs and budget of your business.</p>
                </div>
                <div className="grid lg:grid-cols-3 gap-4">
                    <div className="col-span-1">
                        <div className="border border-bg rounded-md">
                            <div className="rounded-tl-md rounded-tr-md p-6  bg-body-bg bg-cover border-b border-b-bg" style={{ backgroundImage: `url(${background.src})` }}>
                                <h5 className="mb-2 text-xl text-primary">Starter</h5>
                                <h2 className="lg:text-3.2xl md:text-2.8xl text-2.3xl text-dark inline font-bold">$12.99 </h2>
                                <span> / Month</span>
                            </div>
                            <div className="p-6">
                                <h6 className="mb-2 font-semibold">Start Up Starter Packs</h6>
                                <div className="flex gap-4 flex-col mt-6 mb-4">
                                    <div className="gap-1.75 flex">
                                        <div>
                                            <Icon icon='tabler:circle-check' className="iconify text-green size-4" />
                                        </div>
                                        <div>
                                            <h6 className="text-secondary"> Account Aggregation
                                            </h6>
                                        </div>
                                    </div>
                                    <div className="gap-1.75 flex">
                                        <div>
                                            <Icon icon='tabler:circle-check' className="iconify text-green size-4" />
                                        </div>
                                        <div>
                                            <h6 className="text-secondary"> Expense Tracking</h6>
                                        </div>
                                    </div>
                                    <div className="gap-1.75 flex">
                                        <div>
                                            <Icon icon='tabler:circle-check' className="iconify text-green size-4" />
                                        </div>
                                        <div>
                                            <h6 className="text-secondary"> Budgeting Tools </h6>
                                        </div>
                                    </div>
                                    <div className="gap-1.75 flex">
                                        <div>
                                            <Icon icon='tabler:circle-check' className="iconify text-green size-4" />
                                        </div>
                                        <div>
                                            <h6 className="text-secondary"> Transaction Insights </h6>
                                        </div>
                                    </div>
                                    <div className="gap-1.75 flex">
                                        <div>
                                            <Icon icon='tabler:circle-check' className="iconify text-green size-4" />
                                        </div>
                                        <div>
                                            <h6 className="text-secondary"> Basic Security </h6>
                                        </div>
                                    </div>
                                </div>
                                <button className="py-3 px-6.25 w-full bg-primary text-white rounded-full border border-primary border-b-3 border-b-orange-100 hover:bg-orange-200 hover:border-b-orange-300 transition-all duration-300">Get
                                    Started </button>
                            </div>
                        </div>
                    </div>
                    <div className="col-span-1">
                        <div className="border border-bg rounded-md">
                            <div className="rounded-tl-md rounded-tr-md p-6 bg-primary bg-cover border-b border-b-bg" style={{ backgroundImage: `url(${background.src})` }}>
                                <h5 className="mb-2 text-xl text-white">Premium</h5>
                                <h2 className="lg:text-3.2xl md:text-2.8xl text-2.3xl text-white inline font-bold">$145.99</h2>
                                <span className="text-white"> / Month</span>
                            </div>
                            <div className="p-6">
                                <h6 className="mb-2 font-semibold">Start Up Starter Packs</h6>
                                <div className="flex gap-4 flex-col mt-6 mb-4">
                                    <div className="gap-1.75 flex">
                                        <div>
                                            <Icon icon='tabler:circle-check' className="iconify text-green size-4" />
                                        </div>
                                        <div>
                                            <h6 className="text-secondary"> Account Aggregation
                                            </h6>
                                        </div>
                                    </div>
                                    <div className="gap-1.75 flex">
                                        <div>
                                            <Icon icon='tabler:circle-check' className="iconify text-green size-4" />
                                        </div>
                                        <div>
                                            <h6 className="text-secondary"> Expense Tracking</h6>
                                        </div>
                                    </div>
                                    <div className="gap-1.75 flex">
                                        <div>
                                            <Icon icon='tabler:circle-check' className="iconify text-green size-4" />
                                        </div>
                                        <div>
                                            <h6 className="text-secondary"> Budgeting Tools </h6>
                                        </div>
                                    </div>
                                    <div className="gap-1.75 flex">
                                        <div>
                                            <Icon icon='tabler:circle-check' className="iconify text-green size-4" />
                                        </div>
                                        <div>
                                            <h6 className="text-secondary"> Transaction Insights </h6>
                                        </div>
                                    </div>
                                    <div className="gap-1.75 flex">
                                        <div>
                                            <Icon icon='tabler:circle-check' className="iconify text-green size-4" />
                                        </div>
                                        <div>
                                            <h6 className="text-secondary"> Basic Security </h6>
                                        </div>
                                    </div>
                                </div>
                                <button className="py-3 px-6.25  bg-primary text-white w-full rounded-full border border-primary border-b-3 border-b-orange-100 hover:bg-orange-200 hover:border-b-orange-300 transition-all duration-300">Get
                                    Started </button>
                            </div>
                        </div>
                    </div>
                    <div className="col-span-1">
                        <div className="border border-bg rounded-md">
                            <div className="rounded-tl-md rounded-tr-md p-6  bg-body-bg bg-cover border-b border-b-bg" style={{ backgroundImage: `url(${background.src})` }}>
                                <h5 className="mb-2 text-xl text-primary">Enterprise</h5>
                                <h2 className="lg:text-3.2xl md:text-2.8xl text-2.3xl text-dark inline font-bold">$189.99 </h2>
                                <span> / Month</span>
                            </div>
                            <div className="p-6">
                                <h6 className="mb-2 font-semibold">Start Up Starter Packs</h6>
                                <div className="flex gap-4 flex-col mt-6 mb-4">
                                    <div className="gap-1.75 flex">
                                        <div>
                                            <Icon icon='tabler:circle-check' className="iconify text-green size-4" />
                                        </div>
                                        <div>
                                            <h6 className="text-secondary"> Account Aggregation
                                            </h6>
                                        </div>
                                    </div>
                                    <div className="gap-1.75 flex">
                                        <div>
                                            <Icon icon='tabler:circle-check' className="iconify text-green size-4" />
                                        </div>
                                        <div>
                                            <h6 className="text-secondary"> Expense Tracking</h6>
                                        </div>
                                    </div>
                                    <div className="gap-1.75 flex">
                                        <div>
                                            <Icon icon='tabler:circle-check' className="iconify text-green size-4" />
                                        </div>
                                        <div>
                                            <h6 className="text-secondary"> Budgeting Tools </h6>
                                        </div>
                                    </div>
                                    <div className="gap-1.75 flex">
                                        <div>
                                            <Icon icon='tabler:circle-check' className="iconify text-green size-4" />
                                        </div>
                                        <div>
                                            <h6 className="text-secondary"> Transaction Insights </h6>
                                        </div>
                                    </div>
                                    <div className="gap-1.75 flex">
                                        <div>
                                            <Icon icon='tabler:circle-check' className="iconify text-green size-4" />
                                        </div>
                                        <div>
                                            <h6 className="text-secondary"> Basic Security </h6>
                                        </div>
                                    </div>
                                </div>
                                <button className="py-3 px-6.25 w-full bg-primary text-white rounded-full border border-primary border-b-3 border-b-orange-100 hover:bg-orange-200 hover:border-b-orange-300 transition-all duration-300">Get
                                    Started </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

    )
}

export default Pricing