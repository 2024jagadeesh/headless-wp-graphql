import { Icon } from '@iconify/react/dist/iconify.js'
import Image from 'next/image'
import React from 'react'
import about3 from '@/assets/images/about/3.png'

const About = () => {
    return (
        <section className="py-22.5" id="Feature">
            <div className="container">
                <div className="mb-12 lg:w-3/5 mx-auto">
                    <div className="mb-6 flex items-center justify-center">
                        <div className="size-7.5 bg-primary rounded-md flex justify-center items-center">
                            <Icon icon='tabler:info-circle' className="iconify text-white size-4.5 " />
                        </div>
                        <Icon icon='tabler:line-dashed' className="iconify text-primary size-5" />
                        <div className="py-2 px-4 bg-body-bg text-primary border rounded-md text-sm border-bg">
                            About Us
                        </div>
                    </div>
                    <h3 className="mb-2 lg:text-2.8xl md:text-2.5xl text-2.3xl text-center">Why You Should Choose Skywave ?</h3>
                </div>
                <div className="grid lg:grid-cols-12 gap-6 items-center">
                    <div className="lg:col-span-7">
                        <Image src={about3} alt='about3' />
                    </div>
                    <div className="lg:col-span-5">
                        <div>
                            <h5 className="mb-4 text-xl">Skywave offers a comprehensive, user-friendly app experience</h5>
                            <p className="mb-4 text-secondary">Choosing Skywave means partnering with a team that's committed to
                                your success. Our app is designed with your needs in mind, offering an intuitive and
                                user-friendly experience that simplifies your day-to-day tasks.</p>
                            <div className="pt-4">
                                <button className="py-3 px-6.25  bg-primary text-white rounded-full border border-primary border-b-3 border-b-orange-100 hover:bg-orange-200 hover:border-b-orange-300 transition-all duration-300">
                                    Learn More
                                </button>
                            </div>
                            <div className="grid lg:grid-cols-3 mt-6 gap-6">
                                <div className="col-span-1">
                                    <h4 className="mb-2 md:text-2xl text-2.1xl">20+</h4>
                                    <p className="text-secondary">Working Task</p>
                                </div>
                                <div className="col-span-1">
                                    <h4 className="mb-2 md:text-2xl text-2.1xl">70+</h4>
                                    <p className="text-secondary">Country Reached</p>
                                </div>
                                <div className="col-span-1">
                                    <h4 className="mb-2 md:text-2xl text-2.1xl flex justigy-center items-center gap-1"><Icon icon='tabler:star-filled' className="iconify text-yellow size-6" />4.5</h4>
                                    <p className="text-secondary">Best Rating</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

    )
}

export default About