import type { Metadata } from "next";
import { Rethink_Sans } from "next/font/google";
import "swiper/css";
import "swiper/css/navigation";
import "aos/dist/aos.css";

import "./globals.css";

import AppProvidersWrapper from "@/component/wrappers/AppProvidersWrapper";

const inter = Rethink_Sans({
  variable: "--font-inter",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Skywave - IT Solution & Technology TailwindCSS 4 Template",
  description: "Skywave - IT Solution & Technology TailwindCSS 4 Template",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className={inter.variable}>
        <AppProvidersWrapper>{children}</AppProvidersWrapper>
      </body>
    </html>
  );
}
