import React from "react";

import TopBar from "@/component/layouts/components/TopBar";
import Footer from "@/component/layouts/components/Footer";

import Hero from "./agency/components/Hero";
import About from "./agency/components/About";
import Features from "./agency/components/Features";
import Services from "./agency/components/Services";
import Work from "./agency/components/Work";
import Counter from "./agency/components/Counter";
import Testimonial from "./agency/components/Testimonial";
import Pricing from "./agency/components/Pricing";
import Contact from "./agency/components/Contact";

const page = () => {
  return (
    <>
      <TopBar />

      <Hero />
      <About />
      <Features />
      <Services />
      <Work />
      <Counter />
      <Testimonial />
      <Pricing />
      <Contact />

      <Footer />
    </>
  );
};

export default page;
