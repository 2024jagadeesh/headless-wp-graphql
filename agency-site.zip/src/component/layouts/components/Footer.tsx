import Image from 'next/image'
import React from 'react'
import logoLight from '@/assets/images/logo/logo-light.png'
import { Icon } from '@iconify/react/dist/iconify.js'
import Link from 'next/link'

const Footer = () => {
    return (
        <footer className="pt-12 pb-6 bg-dark">
            <div className="container">
                <div className="grid lg:grid-cols-11 md:grid-cols-3 lg:gap-4 gap-8 mt-12 justify-between pb-12">
                    <div className="lg:col-span-3 col-span-2">
                        <Link href="/preview">
                            <Image src={logoLight} width={168} height={30} alt='logo' className="mb-6 h-7.5" />
                        </Link>
                        <p className="mb-6 text-white text-lg">Comprehensive report, data visualization , and insights to analyze
                            your business.</p>
                        <button className="py-1.75 px-4.5 bg-primary text-sm text-white rounded-full border border-primary border-b-3 border-b-orange-100 hover:bg-orange-200 hover:border-b-orange-300 transition-all duration-300">
                            Subscribe
                        </button>
                    </div>
                    <div className="lg:col-span-2 col-span-1">
                        <h5 className="mb-2 text-white text-xl">Solution</h5>
                        <ul className="mt-6 mb-4 ">
                            <li className="mb-4 text-light-400 hover:text-primary transition-all duration-300">Enterprise</li>
                            <li className="mb-4 text-light-400 hover:text-primary transition-all duration-300">By Workflow</li>
                            <li className="mb-4 text-light-400 hover:text-primary transition-all duration-300">By Team</li>
                        </ul>
                    </div>
                    <div className="lg:col-span-2 col-span-1">
                        <h5 className="mb-2 text-white text-xl">Company</h5>
                        <ul className="mt-6 mb-4 ">
                            <li className="mb-4 text-light-400 hover:text-primary transition-all duration-300">About Us</li>
                            <li className="mb-4 text-light-400 hover:text-primary transition-all duration-300">News &amp; Press</li>
                            <li className="mb-4 text-light-400 hover:text-primary transition-all duration-300">Our Customer</li>
                            <li className="mb-4 text-light-400 hover:text-primary transition-all duration-300">Leadership</li>
                            <li className="mb-4 text-light-400 hover:text-primary transition-all duration-300">Careers</li>
                        </ul>
                    </div>
                    <div className="lg:col-span-2 col-span-1">
                        <h5 className="mb-2 text-white text-xl">Company</h5>
                        <ul className="mt-6 mb-4 ">
                            <li className="mb-4 text-light-400 hover:text-primary transition-all duration-300">Blog </li>
                            <li className="mb-4 text-light-400 hover:text-primary transition-all duration-300">Webinar &amp; Events</li>
                            <li className="mb-4 text-light-400 hover:text-primary transition-all duration-300">Podcast</li>
                            <li className="mb-4 text-light-400 hover:text-primary transition-all duration-300">E-book &amp; Guides</li>
                        </ul>
                    </div>
                    <div className="lg:col-span-2 col-span-1">
                        <h5 className="mb-2 text-white text-xl">Contact Us</h5>
                        <ul className="mt-6 mb-4 ">
                            <li className="mb-4 text-light-400 hover:text-primary transition-all duration-300">Contact Sales </li>
                            <li className="mb-4 text-light-400 hover:text-primary transition-all duration-300">Become Partner</li>
                            <li className="mb-4 text-light-400 hover:text-primary transition-all duration-300">Affliate Program</li>
                        </ul>
                    </div>
                </div>
                <hr className="border opacity-10 border-primary my-4" />
                <div className="grid grid-cols-12 gap-6 mt-4 items-center">
                    <div className="col-span-5">
                        <p className="text-light-100">2025
                            © Skywave - Design crafted by ❤️ <a href="#" className="text-white">MarkeyThemes</a>
                        </p>
                    </div>
                    <div className="col-span-4">
                        <div className="flex gap-2.75 justify-center">
                            <a href="#" className="size-10 flex justify-center items-center bg-white rounded-full">
                                <Icon icon='tabler:brand-facebook' className="iconify  text-dark size-4 hover:text-primary" />
                            </a>
                            <a href="#" className="size-10 flex justify-center items-center bg-white rounded-full">
                                <Icon icon='tabler:brand-x' className="iconify  text-dark size-4 hover:text-primary" />
                            </a>
                            <a href="#" className="size-10 flex justify-center items-center bg-white rounded-full">
                                <Icon icon='tabler:brand-youtube' className="iconify  text-dark size-4 hover:text-primary" />
                            </a>
                            <a href="#" className="size-10 flex justify-center items-center bg-white rounded-full">
                                <Icon icon='tabler:brand-instagram' className="iconify  text-dark size-4 hover:text-primary" />
                            </a>
                        </div>
                    </div>
                    <div className="col-span-3">
                        <div className="grid grid-cols-2 gap-6">
                            <a href="#" className="text-white">Terms Of Us</a>
                            <a href="#" className="text-white">Privacy Policy</a>
                        </div>
                    </div>
                </div>
            </div>
        </footer>

    )
}

export default Footer