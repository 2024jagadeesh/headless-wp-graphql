export const currentYear = new Date().getFullYear();
