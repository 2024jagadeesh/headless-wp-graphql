import { ContactSection } from "@/lib/types";

type ContactProps = {
  data?: ContactSection;
};

export default function Contact({ data }: ContactProps) {
  return (
    <section className="py-20">
      <h2 className="text-3xl font-bold">{data?.title}</h2>
      <p className="mt-4">{data?.subtitle}</p>
    </section>
  );
}
