import { FeaturesSection } from "@/lib/types";

type FeaturesProps = {
  data?: FeaturesSection;
};

export default function Features({ data }: FeaturesProps) {
  return (
    <section className="py-20">
      <h2 className="text-3xl font-bold">{data?.title}</h2>

      <div className="grid grid-cols-2 gap-8 mt-8">
        <div>
          <h3 className="font-semibold">{data?.feature1Title}</h3>
          <p>{data?.feature1Desc}</p>
        </div>

        <div>
          <h3 className="font-semibold">{data?.feature2Title}</h3>
          <p>{data?.feature2Desc}</p>
        </div>
      </div>
    </section>
  );
}
