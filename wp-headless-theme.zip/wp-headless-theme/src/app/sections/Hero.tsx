import { HeroSection } from "@/lib/types";

type HeroProps = {
  data?: HeroSection;
};

export default function Hero({ data }: HeroProps) {
  return (
    <section className="py-20 text-center">
      <h1 className="text-4xl font-bold">{data?.heroTitle}</h1>
      <p className="mt-4">{data?.heroSubtitle}</p>

      <button className="mt-6 bg-black text-white px-6 py-2">
        {data?.heroButtonText}
      </button>
    </section>
  );
}
