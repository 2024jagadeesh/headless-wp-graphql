import { getHomePage } from "@/lib/getHomePage";
import Hero from "./sections/Hero";
import Features from "./sections/Features";
import Contact from "./sections/Contact";

export async function generateMetadata() {
  const page = await getHomePage();

  return {
    title: page?.seo?.title || page?.title,
    description: page?.seo?.metaDesc || "",
  };
}

export default async function HomePage() {
  const page = await getHomePage();

  if (!page) {
    return <h1>No page found</h1>;
  }

  const fields = page.homepageSections;

  return (
    <main>
      <Hero data={fields?.heroSection} />
      <Features data={fields?.featuresSection} />
      <Contact data={fields?.contactSection} />
    </main>
  );
}
