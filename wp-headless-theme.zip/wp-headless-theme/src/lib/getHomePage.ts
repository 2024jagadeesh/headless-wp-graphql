import { client } from "./graphql";

export async function getHomePage() {
  const query = `
    query {
      pageBy(uri: "/") {
        title
        seo {
            title
            metaDesc
        }
        homepageSections {
          heroSection {
            heroTitle
            heroSubtitle
            heroButtonText
          }

          featuresSection {
            title
            feature1Title
            feature1Desc
            feature2Title
            feature2Desc
          }

          contactSection {
            title
            subtitle
          }
        }
      }
    }
  `;

  const data = await client.request(query);
  return data.pageBy;
}
