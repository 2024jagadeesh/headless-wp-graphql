import { GraphQLClient } from "graphql-request";

export const client = new GraphQLClient("http://headless-wp.test/graphql");
