export type HeroSection = {
  heroTitle?: string;
  heroSubtitle?: string;
  heroButtonText?: string;
};

export type FeaturesSection = {
  title?: string;
  feature1Title?: string;
  feature1Desc?: string;
  feature2Title?: string;
  feature2Desc?: string;
};

export type ContactSection = {
  title?: string;
  subtitle?: string;
};
